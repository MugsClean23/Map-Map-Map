import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import * as L from "leaflet";
import { createClient } from "@supabase/supabase-js";

// Replace these with your real values from Supabase
const supabaseUrl = "https://your-project-id.supabase.co";
const supabaseKey = "your-anon-public-key";
const supabase = createClient(supabaseUrl, supabaseKey);

const MapPage = () => {
  const [filter, setFilter] = useState({ restaurant: true, park: true, shopping: true });
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    const fetchLocations = async () => {
      const { data, error } = await supabase.from("locations").select("*");
      if (error) {
        console.error("Error fetching locations:", error);
      } else {
        setLocations(data);
      }
    };
    fetchLocations();
  }, []);

  const toggleFilter = (type) => {
    setFilter((prev) => ({ ...prev, [type]: !prev[type] }));
  };

  const getColorIcon = (type) => {
    const color = type === "restaurant" ? "red" : type === "park" ? "green" : "blue";
    return new L.Icon({
      iconUrl: `https://chart.googleapis.com/chart?chst=d_map_pin_letter&chld=%E2%80%A2|${color}`,
      iconSize: [21, 34],
      iconAnchor: [10, 34],
      popupAnchor: [0, -30]
    });
  };

  return (
    <div style={{ height: "100vh", width: "100%", display: "grid", gridTemplateColumns: "1fr 3fr" }}>
      <div style={{ padding: "1rem", backgroundColor: "#fff" }}>
        <h2 style={{ fontSize: "1.25rem", fontWeight: "600" }}>Filters</h2>
        <div style={{ marginTop: "1rem" }}>
          <label><input type="checkbox" checked={filter.restaurant} onChange={() => toggleFilter("restaurant")} /> Restaurants</label><br />
          <label><input type="checkbox" checked={filter.park} onChange={() => toggleFilter("park")} /> Parks/Trails</label><br />
          <label><input type="checkbox" checked={filter.shopping} onChange={() => toggleFilter("shopping")} /> Shopping</label>
        </div>
      </div>
      <div>
        <MapContainer center={[30.324, -86.135]} zoom={14} style={{ height: "100%", width: "100%" }}>
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="&copy; OpenStreetMap contributors"
          />
          {locations.map((loc) =>
            filter[loc.type] ? (
              <Marker
                key={loc.id}
                position={[loc.lat, loc.lng]}
                icon={getColorIcon(loc.type)}
              >
                <Popup>
                  <div style={{ maxWidth: "250px" }}>
                    <img src={loc.photo} alt={loc.name} style={{ width: "100%", borderRadius: "0.5rem" }} />
                    <h3 style={{ fontWeight: "bold", fontSize: "1.1rem", margin: "0.5rem 0" }}>{loc.name}</h3>
                    <p>{loc.address}</p>
                    <p>⏰ {loc.hours}</p>
                    <p>🕰️ {loc.years} years in business</p>
                    <p>💵 {loc.price}</p>
                    <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
                      <a href={loc.website} target="_blank" rel="noopener noreferrer">Website</a>
                      <a href={loc.instagram} target="_blank" rel="noopener noreferrer">Instagram</a>
                      <a href={loc.yelp} target="_blank" rel="noopener noreferrer">Yelp</a>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ) : null
          )}
        </MapContainer>
      </div>
    </div>
  );
};

export default MapPage;